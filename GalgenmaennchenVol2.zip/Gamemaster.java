/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 21.02.2024
 * @author 
 */

public class Gamemaster {
  
  // Anfang Attribute
  private boolean amZug;
  // Ende Attribute
  
  // Anfang Methoden
  public boolean getAmZug() {
    return amZug;
  }

  public void setAmZug(boolean amZugNeu) {
    amZug = amZugNeu;
  }

  // Ende Methoden
} // end of Gamemaster
